/************************************************************************************
 * File                 : MobileRechargeException .java
 * Author Name          : Prasad Mahajan
 * Desc                 : User defined exception
 * Version              : 1.0
 * Last Modified Date   : 18-May-2019
 ************************************************************************************/


package com.cg.mra.exception;

public class MobileRechargeException extends Exception {

	public MobileRechargeException() {
		// TODO Auto-generated constructor stub
	}

	public MobileRechargeException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MobileRechargeException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public MobileRechargeException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public MobileRechargeException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

}
