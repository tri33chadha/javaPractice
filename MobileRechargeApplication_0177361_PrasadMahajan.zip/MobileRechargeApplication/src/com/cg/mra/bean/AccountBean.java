/************************************************************************************
 -> File                 : AccountBean.java
 -> Author Name          : Prasad Mahajan
 -> Desc                 : Create the entities for AccountBean class
 -> Version              : 1.0
 -> Last Modified Date   : 02-May-2019
 ************************************************************************************/

package com.cg.mra.bean;

public class AccountBean {
	private String accountId;
	private String accountType;
	private String customerName;
	private String accountBalance;
	
	/******************************************
	 -> Default constructor initialized
	 ******************************************/
	public AccountBean() {
	
	}
	/******************************************
	 -> Parameterized constructor initialized
	 ******************************************/
	public AccountBean(String accountId, String accountType, String customerName, String accountBalance) {
		super();
		this.accountId = accountId;
		this.accountType = accountType;
		this.customerName = customerName;
		this.accountBalance = accountBalance;
	}
	/******************************************
	 -> Generating getters and setters
	 ******************************************/
	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(String accountBalance) {
		this.accountBalance = accountBalance;
	}
	/******************************************
	 -> Generating toString method
	 ******************************************/
	@Override
	public String toString() {
		return "AccountBean [accountId=" + accountId + ", accountType=" + accountType + ", customerName=" + customerName
				+ ", accountBalance=" + accountBalance + "]";
	}
	

}
