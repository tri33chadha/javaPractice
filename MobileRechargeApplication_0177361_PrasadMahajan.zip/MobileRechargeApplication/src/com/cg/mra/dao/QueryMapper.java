/************************************************************************************
 -> File                 : QueryMapper.java
 -> Author Name          : Prasad Mahajan
 -> Desc                 : Interface for defining queries
 -> Version              : 1.0
 -> Last Modified Date   : 18-May-2019
 ************************************************************************************/

package com.cg.mra.dao;

public interface QueryMapper {
	public static final String GET_ACCOUNT_DETAILS="SELECT account_id,account_type,customer_name,account_balance FROM account where account_id =?";
	public static final String RECHARGE_ACCOUNT="UPDATE account SET account_balance =account_balance + ? WHERE account_id = ?";

}
