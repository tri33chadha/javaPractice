/************************************************************************************
-> File                 : AccountDaoImplTest.java
-> Author Name          : Prasad Mahajan
-> Desc                 : Testing methods of AccountDaoImpl and database connection 
-> Version              : 1.0
-> Last Modified Date   : 18-May-2019
************************************************************************************/
package com.cg.mra.test;

import static org.junit.Assert.*;

import java.sql.Connection;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.bean.AccountBean;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.MobileRechargeException;
import com.cg.mra.util.DBUtil;

public class AccountDaoImplTest {
	static AccountDaoImpl ddaoImpl;
	static AccountBean dbean;
	static Connection conn;
	
	@BeforeClass
	public static void initialize(){
		ddaoImpl = new AccountDaoImpl();
		dbean = new AccountBean();
		conn = null;
	}
	
	/*****************************************************
	 * Before each class test connection is establishing
	 *****************************************************/
	@BeforeClass
	public static void beforeAllTest() throws MobileRechargeException{
		conn = DBUtil.getConnection();
	}
	
	/************************************
	 * Test case for db connection
	 * @throws EnquiryDBException
	 * 
	 ************************************/
	
	@Test
	public void DBUtilTest() throws MobileRechargeException {
		Connection conn = DBUtil.getConnection();
		assertNotNull(conn);
	}
	

	/************************************
	 * Test case for recharge()
	 * @throws MobileRechargeException 
	 * @throws NumberFormatException 
	 * 
	 ************************************/
	@Test
	public void testAdd() throws NumberFormatException, MobileRechargeException{
		dbean.setAccountId("1001");
		dbean.setAccountType("Pre paid");
		dbean.setCustomerName("Prasad");
		dbean.setAccountBalance("50");
	

		
	}
	
