package com.cg.pms.pl;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.cg.pms.beans.Mobiles;
import com.cg.pms.beans.PurchaseDetails;
import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.Service.CustomerServiceImpl;
import com.cg.pms.Service.ICustomerService;

class Main {
	public static void main(String[] args) throws PurchaseException,
			SQLException {
		ICustomerService service = new CustomerServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("-----Menu-----");
			System.out.println("1.Insert customer and Purchase Details");
			System.out.println("2.View mobile details");
			System.out.println("3.Delete mobile details");
			System.out.println("4.Search mobiles based on price range");
			System.out.println("5. Get PurchaseDetails");
			int ch = sc.nextInt();
			switch (ch) {
			case 1:
				PurchaseDetails purchasedetails = new PurchaseDetails();
				System.out.println("Enter Customer Name");
				String cname = sc.next();
				purchasedetails.setCname(cname);
				System.out.println("Enter Email Id");
				String mailid = sc.next();
				purchasedetails.setMailid(mailid);
				System.out.println("Enter Phone Number");
				String phoneno = sc.next();
				purchasedetails.setPhoneno(phoneno);
				LocalDate PurchaseDate = LocalDate.now();
				purchasedetails.setPurchasedate(PurchaseDate);
				System.out.println("Enter MobileId");
				int mobileid = sc.nextInt();
				purchasedetails.setMobileid(mobileid);
				try {
					if (service.validatePurchaseDetails(purchasedetails)) {
						service.addPurchase(purchasedetails);
						System.out.println("Registered Successfully with PurchaseId : "
										+ purchasedetails.getPurchaseid());
					}
				} catch (PurchaseException e) {
					System.err.println(e.getMessage());
				}
				break;
			case 2:
				ArrayList<Mobiles> list = service.getMobiledetails();
				if (list.size() == 0)
					System.out.println("No records found");
				else {
					for (Mobiles m1 : list) {
						System.out.println(m1);
					}
				}
				break;
			case 3:
				System.out.println("Enter MobileId that need to be deleted");
				int mobileid1 = sc.nextInt();
				int j = service.deleteMobileDetails(mobileid1);
				break;
			default:
				System.out.println("Invalid choice...Try Again");
				break;
				// search moblie based on price range
			case 4:
				System.out.println("Enter the mobile price range: ");
				double price=sc.nextDouble();
				List<String> mobiles = service.getMobiles(price);
				for (Iterator<String> iterator = mobiles.iterator(); iterator.hasNext();) {
					String string = iterator.next();
					System.out.println(string);
				}
			case 5:
				System.out.println("Enter the purchase Id");
				int purchaseid=sc.nextInt();
				PurchaseDetails purchaseDetails=service.getPurchaseDetails(purchaseid);
			}
		} while (true);

	}
}
