package com.cg.pms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.pms.Exception.PurchaseException;
import com.cg.pms.Util.DatabaseConnection;
import com.cg.pms.beans.Mobiles;
import com.cg.pms.beans.PurchaseDetails;

public class CustomerDaoImpl implements ICustomerDao {
	Connection con;

	public CustomerDaoImpl() {
		con = DatabaseConnection.getConnection();
	}

	static int purchaseid = 50;

	int generatePurchaseId() {
		// int purchaseid = 0;
		/*
		 * String sql = "select purchaseid_seq.nextval from dual"; try {
		 * PreparedStatement st = con.prepareStatement(sql); ResultSet rs =
		 * st.executeQuery(sql); if (rs.next()) purchaseid = rs.getInt(1); } catch
		 * (SQLException e) { e.printStackTrace(); }
		 */
		return ++purchaseid;
	}

	@Override
	public int addPurchase(PurchaseDetails purchasedetails) {
		String sql = "insert into purchasedetails " + " values(?,?,?,?,?,?)";
		purchasedetails.setPurchaseid(generatePurchaseId());
		int r = 0;
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, purchasedetails.getPurchaseid());
			ps.setString(2, purchasedetails.getCname());
			ps.setString(3, purchasedetails.getMailid());
			ps.setString(4, purchasedetails.getPhoneno());
			ps.setDate(5, Date.valueOf(purchasedetails.getPurchasedate()));
			ps.setInt(6, purchasedetails.getMobileid());
			r = ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		if (r == 1) {
			int quantity = 0;
			sql = "select * from mobiles where mobileid=?";
			con = DatabaseConnection.getConnection();
			try {
				PreparedStatement statement = con.prepareStatement(sql);
				statement.setInt(1, purchasedetails.getMobileid());
				ResultSet rs = statement.executeQuery();
				while (rs.next()) {
					quantity = rs.getInt(4);
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			sql = "update mobiles set quantity=? where mobileid=?";
			con = DatabaseConnection.getConnection();
			try {
				PreparedStatement statement = con.prepareStatement(sql);
				statement.setInt(1, --quantity);
				statement.setInt(2, purchasedetails.getMobileid());
				statement.executeUpdate();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return purchasedetails.getPurchaseid();
	}

	public ArrayList<Mobiles> getMobiledetails() throws PurchaseException {
		ArrayList<Mobiles> list = new ArrayList<Mobiles>();
		String sql = "select * from mobiles";
		con = DatabaseConnection.getConnection();
		try {
			Statement s = con.createStatement();
			ResultSet rs = s.executeQuery(sql);
			while (rs.next()) {
				/*
				 * mobiles mobile=new mobiles(rs.getInt("mobileid"),rs.getString(
				 * "name"),rs.getInt("price"),rs.getString("quantity")); mobilelist.add(mobile);
				 */
				Mobiles mobile = new Mobiles();
				mobile.setMobileid(rs.getInt("mobileid"));
				mobile.setName(rs.getString("name"));
				mobile.setPrice(rs.getInt("price"));
				mobile.setQuantity(rs.getString("quantity"));

				list.add(mobile);
			}

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int deleteDetails(int mobileid) throws SQLException, PurchaseException {
		// TODO Auto-generated method stub
		int mbl = mobileid;
		String sql1 = "delete from mobiles where mobileid=?";
		PreparedStatement st = con.prepareStatement(sql1);
		st.setInt(1, mbl);
		int i = st.executeUpdate();
		return 0;
	}

	/*
	 * @Override public int deleteDetails(int mobileid) { // TODO Auto-generated
	 * method stub return 0; }
	 */

	@Override
	public List<String> getMobiles(double price) {
		ArrayList<String> list = new ArrayList<String>();
		String sql = "select * from mobiles";
		con = DatabaseConnection.getConnection();
		try {
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				String s = "";
				if (rs.getInt("price") >= price) {
					s = s + "    " + rs.getInt("price");
					s = s + "    " + rs.getInt("mobileid");
					s = s + "    " + rs.getString("name");
					s = s + "    " + rs.getString("quantity");
					list.add(s);
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public PurchaseDetails getPurchaseDetails(int purchaseid) throws SQLException {
		String sql = "Select * from purchasedetails where purchaseid=?";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setInt(1, purchaseid);
		ResultSet set = ps.executeQuery();
		PurchaseDetails purchaseDetails = null;
		while (set.next()) {
			purchaseDetails = new PurchaseDetails();
			purchaseDetails.setPurchaseid(set.getInt(1));
			purchaseDetails.setCname(set.getString(2));
			purchaseDetails.setMailid(set.getString(3));
			purchaseDetails.setPhoneno(set.getString(4));
			purchaseDetails.setPurchasedate(set.getDate(5).toLocalDate());
			purchaseDetails.setMobileid(set.getInt(6));
		}
		return purchaseDetails;
	}

}
