package com.capgemini.ttbo.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.ttbo.bean.BookingBean;
import com.capgemini.ttbo.exception.BookingException;

public class JUnitTestDao 
{
	static BookingBean bb;
	
	static long phone;
	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		bb = new BookingBean();
		
	}
	

}
