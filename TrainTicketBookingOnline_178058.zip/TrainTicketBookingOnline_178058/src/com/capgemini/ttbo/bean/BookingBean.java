package com.capgemini.ttbo.bean;

public class BookingBean 
{
	private int bookingId;
	private int noOfSeats;
	private int trainId;
	private String custId;
	public BookingBean(int bookingId, int noOfSeats, int trainId, String custId) {
		super();
		this.bookingId = bookingId;
		this.noOfSeats = noOfSeats;
		this.trainId = trainId;
		this.custId = custId;
	}
	public BookingBean( String custId,int noOfSeats, int trainId) 
	{
		super();
		this.noOfSeats = noOfSeats;
		this.trainId = trainId;
		this.custId = custId;
	}
	public BookingBean() {
		super();
	}
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getNoOfSeats() {
		return noOfSeats;
	}
	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}
	public int getTrainId() {
		return trainId;
	}
	public void setTrainId(int trainId) {
		this.trainId = trainId;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	@Override
	public String toString() {
		return "BookingBean [bookingId = " + bookingId + ", noOfSeats = "
				+ noOfSeats + ", trainId = " + trainId + ", custId = " + custId
				+ "]";
	}
	
	
}
