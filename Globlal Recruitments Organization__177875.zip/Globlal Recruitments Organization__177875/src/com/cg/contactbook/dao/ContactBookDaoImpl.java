package com.cg.contactbook.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import com.cg.contactbook.bean.EnquiryBean;
import com.cg.contactbook.exception.ContactBookexception;
import com.cg.contactbook.util.DatabaseConnection;

public class ContactBookDaoImpl implements ContactBookDao {
	
	
	Logger logger = Logger.getRootLogger();
	//For logger configuration

public ContactBookDaoImpl(){

	PropertyConfigurator.configure("resources//log4j.properties");
}


//------------------------ Global Recruitements --------------------------
	/*******************************************************************************************************
	 - Function Name	:	addEnquiryDetails(EnquiryBean Enqry)
	 - Input Parameters	:	EnquiryBean Enqry
	 - Return Type		:	integer
	 - Throws			:  	EnquiryException
	 - Author			:	V.Sankar Gupta
	 - Creation Date	:	09/05/2019
	 - Description		:	Adding Enquiry Details
	 ********************************************************************************************************/





	Connection conn=null;
	
	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookexception {
		
		conn = DatabaseConnection.getConnection();
		if(conn!=null)
		logger.info("connection successfull");
		enqry.setEnqryid(generateenqryId());
		//String sql="INSERT INTO enquiry VALUES(?,?,?,?,?,?)";
		
		try {
			PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERTION_QUERY);
				pst.setInt(1, enqry.getEnqryid() );
				pst.setString(2, enqry.getFname());
				pst.setString(3, enqry.getlName());
				pst.setString(4, enqry.getContactNo());
				pst.setString(5, enqry.getpDomain());
				pst.setString(6, enqry.getpLocation());
				ResultSet rst=pst.executeQuery();
				logger.info("Details inserted successfull");
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new ContactBookexception("problem in inserting details :");
		}	
		return enqry.getEnqryid();	
	}
	
	/*******************************************************************************************************
	 - Function Name	:	generateEnqId()
	 - Input Parameters	:	no parameters
	 - Return Type		:	integer type
	 - Throws			:  	ContactBookException
	 - Author			:	v.sankargupta
	 - Creation Date	:	02/05/2019
	 - Description		:	To generate sequence from DataBase
	 ********************************************************************************************************/
	private int generateenqryId() throws ContactBookexception  {
		
		
		int enquiryid = 0;
		conn=DatabaseConnection.getConnection();
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QueryMapper.GENERATE_SEQUENCE_QUERY);
			rst.next();
			enquiryid = rst.getInt(1);
		} catch (SQLException e) {
			logger.error("Problem in Generating enquiry Id by using sequence ");
			throw new ContactBookexception("Problem in generating enquiry id"+e.getMessage());
		}
		logger.info("sequence generated successfully");
		return enquiryid;
	}
	
	
	/*******************************************************************************************************
	 - Function Name	:	getEnquiryDetails()
	 - Input Parameters	:	no parameters
	 - Return Type		:	list 
	 - Throws			:  	ContactBookException
	 - Author			:	v.sankargupta
	 - Creation Date	:	02/05/2019
	 - Description		:	retrieving details
	 ********************************************************************************************************/
	


	@Override
	public List<EnquiryBean> getEnquiryDetails() throws ContactBookexception {
		List<EnquiryBean> plist = new ArrayList<EnquiryBean>();

		conn=DatabaseConnection.getConnection();
		
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QueryMapper.RETRIVE_ALL_DETAILS_QUERY);
			while (rst.next()) {	
				EnquiryBean e = new EnquiryBean();
				e.setEnqryid(rst.getInt(1));
				e.setFname(rst.getString(2));
				e.setlName(rst.getString(3));
				e.setContactNo(rst.getString(4));
				e.setpDomain(rst.getString(5));
				e.setpLocation(rst.getString(6));
				plist.add(e);
			}
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new ContactBookexception("Problem in fetching mobiles list"+ e.getMessage());
		}
			logger.info("Enquiry details are fetched from database");
		return plist;

	}

	@Override
	public EnquiryBean getDetails(int id) throws ContactBookexception {
		EnquiryBean e; 
		String sql="Select * from enquiry where Enqryid=?";
		conn = DatabaseConnection.getConnection();
		try {
			 e = new EnquiryBean();
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setInt(1,id);
			ResultSet rst = pst.executeQuery();
	while(rst.next())
	{
			e.setEnqryid(rst.getInt(1));
			e.setFname(rst.getString(2));
			e.setlName(rst.getString(3));
			e.setContactNo(rst.getString(4));
			e.setpDomain(rst.getString(5));
			e.setpLocation(rst.getString(6));
	
	}		
		} catch (SQLException e1) {
		throw new ContactBookexception(e1.getMessage());
		}
		
	
		return e;
	}

}
