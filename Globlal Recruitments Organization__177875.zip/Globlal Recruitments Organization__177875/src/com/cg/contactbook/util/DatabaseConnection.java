package com.cg.contactbook.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import java.util.Properties;

import com.cg.contactbook.exception.ContactBookexception;



public class DatabaseConnection {
	private static Connection conn=null;

	public static Connection getConnection() throws ContactBookexception {
		
		FileInputStream fs = null;	
		try {
			fs=new FileInputStream("resources/jdbc.properties");
			Properties prop = new Properties();
			prop.load(fs);
			String driver = prop.getProperty("driver");
			String url=prop.getProperty("url");
			String user=prop.getProperty("user");
			String password=prop.getProperty("pass");
			
			if(conn == null){

				Class.forName(driver);
				System.out.println("Driver found");
				conn = DriverManager.getConnection(url,user,password);
				System.out.println("connection established");
			}} catch (ClassNotFoundException e) {
				throw new ContactBookexception("Driver not found "+e.getMessage());
			} catch (SQLException e) {
				throw new ContactBookexception("Problem in establishing the connection "+e.getMessage());		
			} catch (FileNotFoundException e){
				System.err.println("Error in finding jdbc properties file");
			} catch (IOException e) {
				System.err.println("Error in fetching file data");

			} 
		
		finally{
				if(fs !=null)
					try{
						fs.close();

					}catch (IOException e){
						System.out.println(e.getMessage());;
					}
				
			}return conn;
	
	}
}