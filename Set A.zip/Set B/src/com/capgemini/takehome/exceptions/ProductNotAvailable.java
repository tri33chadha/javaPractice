package com.capgemini.takehome.exceptions;

public class ProductNotAvailable extends Exception {

	public ProductNotAvailable() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ProductNotAvailable(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ProductNotAvailable(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ProductNotAvailable(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ProductNotAvailable(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
