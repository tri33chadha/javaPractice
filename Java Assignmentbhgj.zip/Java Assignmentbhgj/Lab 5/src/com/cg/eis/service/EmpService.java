package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class EmpService implements EmpServiceInterface {

    public void InsuranceScheme() {

        Employee emp1 = new Employee();

        if ((emp1.getSalary() < 5000) ) {
            System.out.println("Employee ID : " + emp1.getId());
            System.out.println("Employee Name : " + emp1.getName());
            System.out.println("Employee Salary : " + emp1.getSalary());
            System.out.println("Employee Designation : " + emp1.getDesg());
            System.out.println("Employee Insurance Scheme :No Scheme");
        
        }
        else if ((emp1.getSalary() >= 5000 && emp1.getSalary() < 20000)) {
            System.out.println("Employee ID : " + emp1.getId());
            System.out.println("Employee Name : " + emp1.getName());
            System.out.println("Employee Salary : " + emp1.getSalary());
            System.out.println("Employee Designation : " + emp1.getDesg());
            System.out.println("Employee Insurance Scheme : " + Employee.getSchemes3());
        }
        else if ((emp1.getSalary() >= 20000 && emp1.getSalary() < 40000)) {
            System.out.println("Employee ID : " + emp1.getId());
            System.out.println("Employee Name : " + emp1.getName());
            System.out.println("Employee Salary : " + emp1.getSalary());
            System.out.println("Employee Designation : " + emp1.getDesg());
            System.out.println("Employee Insurance Scheme : " + Employee.getSchemes2());
        }
        else if ((emp1.getSalary() >= 40000)) {
            System.out.println("Employee ID : " + emp1.getId());
            System.out.println("Employee Name : " + emp1.getName());
            System.out.println("Employee Salary : " + emp1.getSalary());
            System.out.println("Employee Designation : " + emp1.getDesg());
            System.out.println("Employee Insurance Scheme : " + Employee.getSchemes1());
        }
    
    }
	
	static void validate(double Sal) throws EmployeeException{
        if(Sal<3000)
            throw new EmployeeException("Salary Should be Greater than 3000");
    }
}