package com.cg.eis.service;

public interface EmpServiceInterface {
    
    public void InsuranceScheme();
    static void validate(double Sal) throws EmployeeException();
    
}