package com.cg.eis.bean;

public class Employee {

    public static String name;
    public static int id;
    public static double salary;
    public static String desg;
    public static String Schemes1="A";
    public static String Schemes2="B";
    public static String Schemes3="C";
    
    public static String getSchemes1() {
        return Schemes1;
    }

    public static void setSchemes1(String schemes1) {
        Schemes1 = schemes1;
    }

    public static String getSchemes2() {
        return Schemes2;
    }

    public static void setSchemes2(String schemes2) {
        Schemes2 = schemes2;
    }

    public static String getSchemes3() {
        return Schemes3;
    }

    public static void setSchemes3(String schemes3) {
        Schemes3 = schemes3;
    }

    

    public String getName() {
        return name;
    }

    public void setName(String name) {
        Employee.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        Employee.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        Employee.salary = salary;
    }

    public String getDesg() {
        return desg;
    }

    public void setDesg(String desg) {
        Employee.desg = desg;
    }

}