package com.cg.eis.EmployeeException;

@SuppressWarnings("serial")
public class EmployeeException extends Exception {

    public EmployeeException(String string) {

        super(string);
    }
    
}