package com.cg.JavaAssignmentLab10;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadDataPropertiesFileDisplayConsole {

	public static void main(String[] args) {
		try{
		FileInputStream fis=new FileInputStream("personProps.properties");
		Properties prop=new Properties();
		prop.load(fis);
		System.out.println("Reading Properties from  file.....");
		System.out.println(prop.getProperty("FirstName"));
		System.out.println(prop.getProperty("LastName"));
		System.out.println(prop.getProperty("Gender"));
		System.out.println(prop.getProperty("Age"));
		System.out.println(prop.getProperty("Weight"));
		System.out.println(prop.getProperty("BloodGroup"));
		
	}catch (FileNotFoundException e) {
		e.printStackTrace();
	} catch (IOException e) {
		e.printStackTrace();
	}

	}

}
