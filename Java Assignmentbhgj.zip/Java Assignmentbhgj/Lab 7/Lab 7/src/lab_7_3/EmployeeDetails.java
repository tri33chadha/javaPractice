package com.capgemini.hashdemo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class EmployeeDetails {
    public static HashMap<String, Employee> hashmap = new HashMap<String, Employee>();

    public static void main(String args[]) {
        Employee e1 = new Employee();
        e1.setId(1001);
        e1.setName("sekhar");
        e1.setDesg("SYstemAssociate");
        e1.setSalary(15000);
        hashmap.put("C", e1);

        Employee e2 = new Employee();
        e2.setId(1002);
        e2.setName("Arjun");
        e2.setDesg("programmer");
        e2.setSalary(25000);
        hashmap.put("B", e2);

        Employee e3 = new Employee();
        e3.setId(1003);
        e3.setName("pavan");
        e3.setDesg("Manager");
        e3.setSalary(45000);
        hashmap.put("A", e3);

        Employee e4 = new Employee();
        e4.setId(1004);
        e4.setName("kumar");
        e4.setDesg("clerk");
        e4.setSalary(4500);
        hashmap.put("N", e4);

        // Accept scheme from end user and retrieving employee details
        Scanner sc = new Scanner(System.in);

        System.out.println("\nAvailable Scheme are:{A,B,C,N (No Scheme)}\n");
        System.out.println("\nEnter the employee Scheme::\n");
        String scheme = sc.next();
        System.out.println("\nThe Employee details of selected Scheme: \n\n"
                + hashmap.get(scheme));

        System.out.println("\n....................................................\n");
        
        //Schemes and Employee Details in Database
        System.out.println("\nSchemes and Employee Details in Database are : \n");
        for(Map.Entry<String, Employee> entry:hashmap.entrySet()){    
            String key=entry.getKey();  
            Employee b=entry.getValue();  
            System.out.println("\nScheme "+key+" Details:\n");  
            System.out.println(hashmap.get(scheme)+" "+b.getId()+" "+b.getName()+" "+b.getDesg()+" "+b.getSalary());   
        }
        
        System.out.println("\n....................................................\n");
        
        System.out.println("\nEnter the Scheme to be delete::\n");
        String scheme1 = sc.next();

        // Removing the existing key mapping
        Employee returned_value = hashmap.remove(scheme1);

        // Verifying the returned value
        System.out.println("\nDeleted Scheme is: \n" + returned_value);

        System.out.println("\n....................................................\n");
        
        //Displaying Remaining Scheme Details
        System.out.println("\nRemaining Scheme Details are : \n");
        for(Map.Entry<String, Employee> entry:hashmap.entrySet()){    
            String key=entry.getKey();  
            Employee b=entry.getValue();  
            System.out.println("\nScheme "+key+" Details:\n");  
            System.out.println(b.getId()+" "+b.getName()+" "+b.getDesg()+" "+b.getSalary());   
        }    
        
        System.out.println("\n....................................................\n");
        
        System.out.println("\nSorting Employee based on Salry : \n");
        List<Employee> employeeBySalary = new ArrayList<>(hashmap.values());

        Collections.sort(employeeBySalary, Comparator.comparing(Employee::getSalary));
        
        //Ordering Employee based on Salary
        
        for (Employee p : employeeBySalary) {
            System.out.println(p.getId()+"\t"+p.getName()+"\t"+p.getDesg() + "\t" + p.getSalary());
        }

        sc.close();
    }

}
