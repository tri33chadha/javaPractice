package com.capgemini.hashdemo;

public class Employee {

    private static String name;
    private static int id;
    private static double salary;
    private static String desg;
    
    //Getting Values using Getters and Setters 
        

    public String getName() {
        return name;
    }

    public void setName(String name) {
        Employee.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        Employee.id = id;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        Employee.salary = salary;
    }

    public String getDesg() {
        return desg;
    }

    public void setDesg(String desg) {
        Employee.desg = desg;
    }

	@Override
	public String toString() {
		return "Employee [Name=" + getName() + ", ID=" + getId()
				+ ", Salary=" + getSalary() + ", Desgination=" + getDesg()
				+ "]";
	}

    
}