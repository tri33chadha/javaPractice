package lab_3_5;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class WarantyOfProduct {
    
    public void Waranty(){
        
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Purchase Date in format dd-MMM-yyyy\n");
        String PurchaseDate = sc.next();
        System.out.println("Enter Warranty Perod (No of Years) : \n");
        int WarrantyPeriodYears = sc.nextInt();
        System.out.println("Enter Warranty Perod (No Of Months) : \n");
        int WarrantyPeriodMonths = sc.nextInt();
        
        sc.close();
        
        Calendar calMonths = Calendar.getInstance();
        Calendar calYears = Calendar.getInstance();
        Calendar calYearsandMonths = Calendar.getInstance();
        
        SimpleDateFormat PurchaseDateFormat = new SimpleDateFormat("dd-MMM-yyyy");
        java.util.Date Purchasedate = null;
        try
        {
            Purchasedate = PurchaseDateFormat.parse(PurchaseDate);
            calMonths.setTime(Purchasedate);
            calYears.setTime(Purchasedate);
            calYearsandMonths.setTime(Purchasedate);
            System.out.println("\nThe Purchase Date is : "+Purchasedate);
            
            calYears.add(Calendar.YEAR,WarrantyPeriodYears);
            calMonths.add(Calendar.MONTH,WarrantyPeriodMonths);
            
            calYearsandMonths.add(Calendar.YEAR,WarrantyPeriodYears);
            calYearsandMonths.add(Calendar.MONTH,WarrantyPeriodMonths);
            
            Date NewDateInMonths =  calMonths.getTime();
            Date NewDateInYears =  calYears.getTime();
            Date NewDateInMonthsAndYears =  calYearsandMonths.getTime();
            
            System.out.println("\nWarranty Period interms of Years : "+NewDateInYears );
            System.out.println("\nWarranty Period interms of Months : "+NewDateInMonths );
            System.out.println("\nWarranty Period interms of Years and Months : "+NewDateInMonthsAndYears );
        
        }
        catch(ParseException e)
        {
            System.out.println("Enter Purchase Date in Correct Format\n");
        }
        
    }
}