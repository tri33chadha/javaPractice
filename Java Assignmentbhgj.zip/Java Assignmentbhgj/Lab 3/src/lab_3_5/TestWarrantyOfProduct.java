package lab_3_5;

public class TestWarrantyOfProduct {

    public static void main(String[] args) {

        WarantyOfProduct check = new WarantyOfProduct();
        check.Waranty();
    }

}