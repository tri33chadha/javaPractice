package com.capgemini.javaclasslib.stringoperations;

import java.util.Scanner;

public class ReplacePos {

    public void replacePos(String str1){
       
        Scanner in = new Scanner(System.in);
        
        in.close();
        int length = str1.length();
        for(int j=0;j<(length);j++)
        {
            if(j%2==0)
            {
                str1 = str1.replace(str1.charAt(j), '#');
            }
            
        }
        System.out.println("The Replaced String with '#' is : "+str1);
    }
}