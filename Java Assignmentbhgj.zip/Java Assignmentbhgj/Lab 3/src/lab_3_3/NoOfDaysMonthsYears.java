package lab_3_3;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;

public class NoOfDaysMonthsYears {

    public void TimePeriod(){
        
        LocalDate GivenDate = LocalDate.of(2016,Month.JULY,30);
        LocalDate CurrentDate = LocalDate.now();
        
        Period period = GivenDate.until(CurrentDate);
        
        System.out.println("Days:"+ period.getDays());
        System.out.println("Months:"+period.getMonths());
        System.out.println("Years:"+ period.getYears());        
    }
}