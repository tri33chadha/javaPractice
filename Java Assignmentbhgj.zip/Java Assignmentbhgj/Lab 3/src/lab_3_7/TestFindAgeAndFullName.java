package lab_3_7;

import java.util.Scanner;

public class TestFindAgeAndFullName {

	public static void main(String[] args) {
		FindAgeAndFullName person = new FindAgeAndFullName();
		person.setFullName("Arjun Yadav","Putti");
		 System.out.println("\nEnter Date Of Birth in format dd-MMM-yyyy\n");
		 
		    Scanner sc = new Scanner(System.in);
		    String DateOfBirth = sc.next();
		    sc.close();
		  
		System.out.println("\nPersonal Detals:");
		System.out.println("---------------------\n");
		System.out.println("\nFull Name : "+person.getFullName());
		person.CalcAge(DateOfBirth);
		
	}

}
