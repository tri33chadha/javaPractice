package lab_3_7;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Date;

public class FindAgeAndFullName {

	public String FirstName;
	public String LastName;
	public String DateOfBirth;

	public void setFullName(String firstName,String lastName){
		this.FirstName = firstName;
		this.LastName  = lastName;
	}
	public String getFullName(){
		
		return (FirstName+" "+LastName);
	}
public void CalcAge(String DOB){
		this.DateOfBirth=DOB;
	    
	    SimpleDateFormat DateFormat = new SimpleDateFormat("dd-MMM-yyyy");
	    Date dateOfBirth=null;
        try
        {
        	dateOfBirth = DateFormat.parse(DateOfBirth);
        	
        	System.out.println("\nDate of birth : "+dateOfBirth);
            LocalDate CurrentDate = LocalDate.now();
            LocalDate date = dateOfBirth.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
            Period period = date.until(CurrentDate);
            System.out.println("\nAge of Person : "+period.getYears()+" Years "
            		+period.getMonths()+" Months "+period.getDays()+ " Days ");
        }
        catch(ParseException e)
        {
            System.out.println("Enter Date of Birth in Correct Format\n");
        }

	}
	
}
