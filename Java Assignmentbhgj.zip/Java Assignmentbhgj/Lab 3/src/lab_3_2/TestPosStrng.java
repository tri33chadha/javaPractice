package lab_3_2;

public class TestPosStrng {

    public static void main(String[] args) {

        PosStrng output = new PosStrng();
        output.CheckStrng();
    }

}