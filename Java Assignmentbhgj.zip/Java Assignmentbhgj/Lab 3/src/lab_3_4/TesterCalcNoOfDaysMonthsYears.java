package lab_3_4;

public class TesterCalcNoOfDaysMonthsYears {

    public static void main(String[] args) {

        CalcNoOfDaysMonthsYears Check = new CalcNoOfDaysMonthsYears();
        Check.TimePeriod();
    }

}