package com.capgemini.classesandobjects.positiveornegative;

public class PositiveOrNegative {

	public static void main(String[] args) {

		// Getting Values from Command Line and checking whether it is positive or negative.
		
		for (int i = 0; i < args.length; i++) {
			
			if (Integer.parseInt(args[i]) >= 0) {
				
				System.out.println("positive number");
				
			} else
				
				System.out.println("negative number");
		}
	}

}
