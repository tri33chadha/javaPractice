package com.capgemini.classesandobjects.usingenum;

//Creating Enum to store Gender values 

 enum Gender{
	  MALE, FEMALE, OTHERS
	} 

public class GenderUsingEnum {

	//Getting Values using Getter and Setter
	
	private String FirstName;
	private String LastName;
	private Gender gender;
	private String Number;

	public String getFirstName(){
		return this.FirstName;
	}
	public void setFirstName(String firstName){
		this.FirstName = firstName;
	}
	
	public String getLastName(){
		return this.LastName;
	}
	public void setLastName(String lastName){
		this.LastName = lastName;
	}
	
	public Gender getGender(){
		return gender;
	}
	public void setGender(Gender gender){
		this.gender = gender;
	}
	
	public String getNumber(){
		return this.Number;
	}
	
	
	public void setNumber(String number){
		this.Number = number;
	}
	
} 
