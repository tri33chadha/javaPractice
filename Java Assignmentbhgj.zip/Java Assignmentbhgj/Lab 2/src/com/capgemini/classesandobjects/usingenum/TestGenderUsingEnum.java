package com.capgemini.classesandobjects.usingenum;

import java.util.Scanner;

public class TestGenderUsingEnum {

	public static void main(String[] args) {

		//Initializing Object and Reading Values using Scanner 
		
		GenderUsingEnum person = new GenderUsingEnum();
		Scanner Sc=new Scanner(System.in);
		   System.out.println("Enter First Name:");
		   String Fname=Sc.nextLine();
		   System.out.println("Enter Last Name:");
		   String LName=Sc.nextLine();
		   System.out.println("Enter Gender:");
		   char Gen=Sc.next().charAt(0);
		   System.out.println("Enter Phone Number");
		   String Num = Sc.next();
		   Sc.close();
		   
		
		person.setFirstName(Fname);
		person.setLastName(LName);
		
		//Getting The Value of Gender from Enum for giving Input
			if(Gen=='M')
			{
				person.setGender(Gender.MALE);
			}
			else if(Gen=='F')
			{
				person.setGender(Gender.FEMALE);
			}
			else if(Gen == 'O')
			{
				person.setGender(Gender.OTHERS);
			}
		
		person.setNumber(Num);
	
		//Displaying Details of Person
		
		System.out.println("\nPersonal Detals:");
		System.out.println("---------------------\n");
		System.out.println("\nLast Name : "+person.getFirstName()+"\nFirst Name : "+person.getLastName()
				+"\nEnter Phone Number : "+person.getNumber());
		
		if(person.getGender()==null)
		{
			System.out.println("\nEnter Either M (Male) or F (Female) or O (Others) Only");
		}
		else
		{
			
			System.out.println("Gender : " + person.getGender());
		}
	}

	}

