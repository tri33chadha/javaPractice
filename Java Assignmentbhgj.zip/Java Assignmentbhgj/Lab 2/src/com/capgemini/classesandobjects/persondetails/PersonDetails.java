package com.capgemini.classesandobjects.persondetails;

import java.util.Scanner;

public class PersonDetails {

	public static void main(String[] args) {

		//Reading Values Using Scanner 
		
		Scanner in = new Scanner(System.in);
		System.out.println("Enter First Name :");
		String FName = in.nextLine();
		System.out.println("Enter Last Name : ");
		String LName = in.nextLine();
		System.out.println("Enter Gender : ");
		char Gender = in.next().charAt(0);
		System.out.println("Enter Age : ");
		int Age = in.nextInt();
		System.out.println("Enter Weight : ");
		float Weight = in.nextFloat();
		in.close();
		
		//Displaying Person Details
		
		System.out.println("\nPersonal Detals:");
		System.out.println("---------------------\n");
		System.out.println("Enter First Name : "+FName);
		System.out.println("Enter Last Name : "+LName);
		System.out.println("Enter Gender : "+Gender);
		System.out.println("Enter Age : "+Age);
		System.out.println("Enter Weight : "+Weight);
	}

}
