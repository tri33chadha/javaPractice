package com.capgemini.classesandobjects.personwithnumber;

public class WithPhoneNumber {

	public String FirstName;
	public String LastName;
	public char Gender;
	public String Number;

	// Getting Values of Person using Getter and Setter
	
	public String getFirstName(){
		return this.FirstName;
	}
	public void setFirstName(String firstName){
		this.FirstName = firstName;
	}
	
	public String getLastName(){
		return this.LastName;
	}
	public void setLastName(String lastName){
		this.LastName = lastName;
	}
	
	public char getGender(){
		return this.Gender;
	}
	public void setGender(char gender){
		this.Gender = gender;
	}
	
	public String getNumber(){
		return this.Number;
	}
	
	
	public void setNumber(String number){
		this.Number = number;
	}
	
}
