package com.capgemini.classesandobjects.personwithnumber;

import java.util.Scanner;

public class TestWithPhoneNumber {

	public static void main(String[] args) {
		
		//Reading values of Person 
		
		Scanner Sc=new Scanner(System.in);
		   System.out.println("Enter First Name:");
		   String Fname=Sc.nextLine();
		   System.out.println("Enter Last Name:");
		   String LName=Sc.nextLine();
		   System.out.println("Enter Gender:");
		   char Gen=Sc.next().charAt(0);
		   System.out.println("Enter Phone Number");
		   String Num = Sc.next();
		   Sc.close();
		   
		   // Initializing  Object with name Person
		   
		WithPhoneNumber person = new WithPhoneNumber();
		person.setFirstName(Fname);
		person.setLastName(LName);
		person.setGender(Gen);
		person.setNumber(Num);

		
		System.out.println("\nPersonal Detals:");
		System.out.println("---------------------\n");
		System.out.println("\nLast Name : "+person.getFirstName()+"\nFirst Name : "+person.getLastName()
					+"\nGender : "+person.getGender()+"\nEnter Phone Number : "+person.getNumber());
		
		
	}

}
