package com.capgemini.classesandobjects.person;

public class TestPersonUsingGetAndSet {

public static void main(String[] args) {
		
	//Initializing object PersonUsingGetAndSet with person
	
		PersonUsingGetAndSet person = new PersonUsingGetAndSet();
		
		person.setFirstName("Arjun Yadav");
		person.setLastName("Putti");
		person.setGender('M');
		
		System.out.println("\nPersonal Detals:");
		System.out.println("---------------------\n");
		System.out.println("\nLast Name : "+person.getFirstName()+"\nFirst Name : "+person.getLastName()+"\nGender : "+person.getGender());


	}

}
