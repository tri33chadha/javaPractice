package lab_6_2;

public class AccountException {

    private long AccountNumber;
    private String AccountHolder;
    protected double Balance;
    private double Deposit;
    protected double Withdrawl;
    private int Age;
    
    public void setAccNumber(long accNumber){
        this.AccountNumber = accNumber;
    }
    public long getAccNumber(){
        return AccountNumber;
    }
    
    public  void setAccHolder(String accHolder){
        this.AccountHolder = accHolder;
    }
    public String getAccHolder(){
        return AccountHolder;
    }
    
    public void setAge(int age){
        this.Age = age;
    }
    public int getAge(){
        return Age;
    }
    
    public void setBalance(double balance){
        
        this.Balance = balance;
    }
    public double getBalance(){
        return Balance;
    }

    public void setDeposit(double deposit){
        this.Deposit = deposit;
    }
    public double getDeposit(){
        return Deposit;
    }
    
    public void setWithdrawl(double withdrawl){
        this.Withdrawl = withdrawl;
    }
    public double getWithdrawl(){
        return Withdrawl;
    }
    
    public double deposit(){
        this.Balance = Balance + Deposit;
        System.out.println("Deposit Amount : " + getDeposit());
        System.out.println("Updated Balance : " + Balance);
        return Balance;
    }
    
    public double withdrawl(){
        this.Balance = Balance - Withdrawl;
        System.out.println("Withdraw Amount : " + getWithdrawl());
        System.out.println("Updated Balance : " + Balance);
        return Balance;
    }
    
    public void display(){
        System.out.println("Account Number : " + getAccNumber());
        System.out.println("Account Holder : " + getAccHolder());
        System.out.println("Age : " + getAge());
        System.out.println( "Current Balance : " +getBalance());
    }
}