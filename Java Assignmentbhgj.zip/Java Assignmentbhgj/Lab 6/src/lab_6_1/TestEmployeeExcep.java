package lab_6_1;

@SuppressWarnings("serial")
class NullException extends Exception{

    public NullException(String str){
        super(str);
    }
}

public class TestEmployeeExcep {

    public static void main(String[] args) throws NullException {

        EmployeeExcep person = new EmployeeExcep();
        
        person.setFirstName(null);
        person.setLastName("Putti");
        person.setGender('M');
        
        if(person.getLastName()==null||person.getFirstName()==null||person.getLastName()==""||person.getFirstName()==""){
            throw new NullException("Enter valid Name");
        }
        else{
        System.out.println("\nPersonal Detals:");
        System.out.println("---------------------\n");
        System.out.println("\nFirst Name : "+person.getFirstName()+"\nLast Name : "+person.getLastName()+"\nGender : "+person.getGender());
        }
        
    }

}