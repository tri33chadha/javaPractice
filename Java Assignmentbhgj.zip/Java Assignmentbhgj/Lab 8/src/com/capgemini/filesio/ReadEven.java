package com.capgemini.filesio;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class ReadEven {

	public static void main(String[] args) {

		try {
			
			//Reading the Text file using Scanner Class
			File f = new File("numbers.txt");
			f.createNewFile();
			Scanner sc = new Scanner(new File("numbers.txt"));
			sc.useDelimiter(",");
			
			//Code to Display only even numbers
			for(int i=1;i<=10;i++)
				if(i%2==0)
				System.out.println(i);
			System.out.println("Successfully Read from the file.");
			sc.close();
		}

		//Exception case
		catch (IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
}
