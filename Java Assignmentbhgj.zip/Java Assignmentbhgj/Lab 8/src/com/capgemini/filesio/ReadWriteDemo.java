package com.capgemini.filesio;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class ReadWriteDemo {

	public static void main(String[] args) throws IOException {
		
		 try {
			 //Creating New File
		      FileWriter writer = new FileWriter("filename.txt");
		     
		      //Writing Text in to File 
		      writer.write("Is it left or Right?");
		      writer.close();
		      System.out.println("\nWritten Operation on file was Successful");
		     
		      //Reading File
		      FileReader f = new FileReader("filename.txt");
		      Scanner reader = new Scanner(f); 
		      
		      //Converting Into mirror Image.
		      while (reader.hasNextLine()) {
		       String data = reader.nextLine();
		        System.out.println("\n"+data+"\n");
		      
		        System.out.println("Read from the file Completed Succefully");
		     
		      StringBuilder s=new StringBuilder("\n"+data+"\n");
		      System.out.println(s.reverse());
		      }
		      reader.close();
		    } 
		 
		//Exception case
		 catch (IOException e) 
		 {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    } 
}
}
