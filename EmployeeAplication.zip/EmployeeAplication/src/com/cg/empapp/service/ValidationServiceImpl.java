package com.cg.empapp.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class ValidationServiceImpl implements ValidationService{

	@Override
	public boolean validateFname(String fname) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(fname);
		return matcher.matches();
	}

	@Override
	public boolean validateLname(String lname) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(lname);
		return matcher.matches();
	}

	@Override
	public boolean validateGender(String gender) {
		Pattern pattern= Pattern.compile("[A-Z]{1}");
		Matcher matcher= pattern.matcher(gender);
		return matcher.matches();
	}
	
	@Override
	public boolean validateJoiningdate(String joiningdate) {
				LocalDate jd;
		        String date= joiningdate;
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MMM/yyyy");
				jd = LocalDate.parse(date, formatter);
				return true;
	}
	
	
	@Override
	public boolean validateMail(String mail) {
		Pattern pattern= Pattern.compile("[A-Za-z0-9]*@capgemini.com");
		Matcher matcher= pattern.matcher(mail);
		return matcher.matches();
	}

	@Override
	public boolean validateMobileno(String mobileno) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(mobileno);
		return matcher.matches();
	}

	@Override
	public boolean validateDeptid(String deptid) {
		Pattern pattern= Pattern.compile("[0-9]{1}");
		Matcher matcher= pattern.matcher(deptid);
		return matcher.matches();
	}

	@Override
	public boolean validateDesignation(String designation) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(designation);
		return matcher.matches();
	}



	

}
