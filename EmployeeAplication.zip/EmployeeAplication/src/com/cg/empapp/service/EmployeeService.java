package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;

public interface EmployeeService {

	public int addEmployee(Employee employee)throws EmployeeException;
	public int updateEmployee(Employee emp) throws EmployeeException;
	public List<Employee> getEmployeeList() throws EmployeeException;
}
