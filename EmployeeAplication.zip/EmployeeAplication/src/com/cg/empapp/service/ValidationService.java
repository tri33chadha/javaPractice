package com.cg.empapp.service;

public interface ValidationService {

	public boolean validateFname(String fname);
	public boolean validateLname(String lname);
	public boolean validateGender(String gender);
	public boolean validateJoiningdate(String joiningdate);
	public boolean validateMail(String mail);
	public boolean validateMobileno(String mobileno);
	public boolean validateDeptid(String deptid);
	public boolean validateDesignation(String designation);
}
