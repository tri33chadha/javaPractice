package com.cg.empapp.service;

import java.util.List;

import com.cg.empapp.dao.EmployeeDao;
import com.cg.empapp.dao.EmployeeDaoImpl;
import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;


public class EmployeeServiceImpl implements EmployeeService{

	EmployeeDao dao;
	public EmployeeServiceImpl(){
			dao= new EmployeeDaoImpl();
	}
	@Override
	public int addEmployee(Employee employee) throws EmployeeException {
		int id = dao.addEmployee(employee);
		return id;
	}
	@Override
	public int updateEmployee(Employee emp) throws EmployeeException {
		return dao.updateEmployee(emp);
	}
	@Override
	public List<Employee> getEmployeeList() throws EmployeeException {
		return dao.getEmployeeList();
	}

}
