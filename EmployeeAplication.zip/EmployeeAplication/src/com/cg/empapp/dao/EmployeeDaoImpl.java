package com.cg.empapp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.util.DatabaseConnection;



public class EmployeeDaoImpl implements EmployeeDao{


	Connection connection;
	public EmployeeDaoImpl() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@Override
	public int addEmployee(Employee employee)throws EmployeeException {
	
  String insQry=
	"INSERT INTO employee (empid , fname ,lname ,gender ,mobileno ,mail ,designation ,salary ,joiningdate ,deptid) values (empid_seq.nextval,?,?,?,?,?,?,?,?,?) ";
	try {
		PreparedStatement ps = connection.prepareStatement(insQry);
		
		ps.setString(1, employee.getFname());
		ps.setString(2, employee.getLname());
		ps.setString(3, employee.getGender());
		ps.setString(4, employee.getMobileno());
		ps.setString(5, employee.getMail());
		ps.setString(6, employee.getDesignation());
		ps.setDouble(7,employee.getSalary());
		ps.setString(8, employee.getJoiningdate());
		ps.setInt(9, employee.getDeptid());
		
		
		int r= ps.executeUpdate();
		int employeeid=0;
		if(r==1){
				Statement st= connection.createStatement();
				ResultSet rs= st.executeQuery("select empid_seq.currval from dual");
				if(rs.next())
					employeeid=rs.getInt(1);
		}
	return employeeid;
	} catch (SQLException e) {
		throw new EmployeeException(e.getMessage());
	}
}

@Override
public List<Employee> getEmployeeList() throws EmployeeException{
	
	
		String selQry= "select empid , fname ,lname ,gender ,mobileno ,mail ,designation ,salary ,joiningdate ,deptid from employee ";
		List<Employee> employeelist= new ArrayList<Employee>();
		try {
			PreparedStatement ps= connection.prepareStatement(selQry);
			ResultSet rs= ps.executeQuery();
			
			while( rs.next()){
				Employee emp= new Employee ();
				emp.setEmpid(rs.getInt(1));
				emp.setFname(rs.getString(2));
				emp.setLname(rs.getString(3));
				emp.setGender(rs.getString(4));
				emp.setMobileno(rs.getString(5));
				emp.setMail(rs.getString(6));
				emp.setDesignation(rs.getString(7));
				emp.setSalary(rs.getDouble(8));
				emp.setJoiningdate(rs.getString(9));
				emp.setDeptid(rs.getInt(10));
				employeelist.add(emp);
			}			
		} catch (SQLException e) {
			throw new EmployeeException(e.getMessage());
		}		
		return employeelist;
}

@Override
public int updateEmployee(Employee emp) throws EmployeeException{
	
	String updateQry= "update employee set salary=? where empid=?";
	try {
		PreparedStatement ps= connection.prepareStatement(updateQry);
		ps.setDouble(1, emp.getSalary());
		ps.setInt(2, emp.getEmpid());
		int rs= ps.executeUpdate();
		return rs;
	} catch (SQLException e) {
		throw new EmployeeException(e.getMessage());
	}
}

}
