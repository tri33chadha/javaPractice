package com.cg.empapp.pl;

import java.util.List;
import java.util.Scanner;

import com.cg.empapp.dto.Employee;
import com.cg.empapp.exception.EmployeeException;
import com.cg.empapp.service.EmployeeService;
import com.cg.empapp.service.EmployeeServiceImpl;
import com.cg.empapp.service.ValidationService;
import com.cg.empapp.service.ValidationServiceImpl;

//import org.apache.log4j.Logger;
//import org.apache.log4j.PropertyConfigurator;




public class Client {
	
	public static void main(String[] args) {

	//PropertyConfigurator.configure("resources/log4j.properties");
	Employee employee= new Employee();
	EmployeeService service= new EmployeeServiceImpl();
	//Logger logger=Logger.getLogger(Client.class);
	ValidationService validation=new ValidationServiceImpl();
	Scanner sc= new Scanner(System.in);
	int option=0;
	String joiningdate;
	do{
    System.out.println("\n\n1. Add Employee Details ...");
	System.out.println("2. Display Mobile List ...");
    System.out.println("3. Update Mobile Quantity ");
	System.out.println("4. Exit");
	System.out.println("Enter Choice .");
	 option= sc.nextInt();
	switch(option){
	
	
	case 1 :

		
	do{
	System.out.println("Enter Employee First Name : ");
	String fname=sc.next();
	boolean res=validation.validateFname(fname);
	if(res==true)
	{
		employee.setFname(fname);
		break;
	}
	else{
		System.out.println("Name should contain only alphabets...First Letter Capital");
	//logger.info("Name should contain only alphabets...First Letter Capital");
	}
	}while(true);
	
	
	do{
		System.out.println("Enter Employee Last Name : ");
		String lname =sc.next();
		boolean res=validation.validateLname(lname);
		if(res==true)
		{
			employee.setFname(lname);
			break;
		}
		else{
			System.out.println("Name should contain only alphabets...First Letter Capital");
		//logger.info("Name should contain only alphabets...First Letter Capital");
		}
		}while(true);
	
	
	do{
		System.out.println("Enter Gender: ");
		String gender =sc.next();
		boolean res=validation.validateGender(gender);
		if(res==true)
		{
			employee.setGender(gender);
			break;
		}
		else{
			System.out.println("Gender should contain only One Capital Letter alphabet(M/F)");
		//logger.info("Name should contain only alphabets...One Letter Capital");
		}
		}while(true);
	
	
	do{
		System.out.println("Enter Mobile No : ");
		String mobileno =sc.next();
		boolean res=validation.validateMobileno(mobileno);
		if(res)
		{
			employee.setMobileno(mobileno);
			break;
		}
		else{
			System.out.println("Mobile no: should be 10 digit.");
		//logger.info("Mobile no: should be 10 digit.");
		}
	}while(true);
	
	
	
	do{
	System.out.println("Enter Mail : ");
	String mail= sc.next();
	boolean res= validation.validateMail(mail);
	if(res==true)
		{
			employee.setMail(mail);
			break;
		}
		else{
			System.out.println("Mail id as: abcd@capgemini.com ");
	//logger.info("Mail id as: abcd@capgemini.com ");
		}
	}while(true);
	
	
	
	/*System.out.println("Enter Employee ID : ");
	int empid =sc.nextInt();*/
	//employee.setEmpid(empid);
	
	
	do{
		System.out.println("Enter Dept ID : ");
		String deptid =sc.next();
		if(validation.validateDeptid(deptid)){
			int id= Integer.parseInt(deptid);
			employee.setDeptid(id);
			break;
		}
		else{
			System.out.println("dept id should be 1 digit number ");
		    //logger.info("mobile id should be 4 digit number ");
		}
	}while(true);
	
	
	do{
		System.out.println("Enter Designation : ");
		String designation =sc.next();
		boolean res=validation.validateLname(designation);
		if(res==true)
		{
			employee.setDesignation(designation);
			break;
		}
		else{
			System.out.println("Designation should contain only alphabets...First Letter Capital");
		//logger.info("Name should contain only alphabets...First Letter Capital");
		}
		}while(true);
	
	
	System.out.println("Enter Salary : ");
	double salary= sc.nextDouble();
	employee.setSalary(salary);
	
	
	System.out.println("Enter Joining Date : ");
	do{
		try {
			joiningdate= sc.next();
			boolean res= validation.validateJoiningdate(joiningdate);
			if(res==true)
				{
				employee.setJoiningdate(joiningdate);
					break;
				}
				else{
					System.out.println("Enter Joining Date (dd/MMM/yyyy) : ");
			//logger.info("Enter Joining Date (dd/MM/yyyy) :");
				}
			break;
		} catch (Exception e) {
			System.out.println("Invalid date entered..");
			//logger.error("Invalid date entered..");
		}
		}while(true);
	    
	
	
	try {
		int empid= service.addEmployee(employee);
		System.out.println("Employee added : "+ empid );
		//logger.info(""Employee added : "+ empid );
	} catch (EmployeeException e) {
		System.out.println(e.getMessage());
		//logger.error(e.getMessage());
	}	
	break;
	
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	
	
	case 2 :
		
		
	//display all employee details on console.
	try {
		List<Employee> employee1= service.getEmployeeList();
		if(employee1.size()>0){
		for(Employee emp :employee1 ){
			System.out.print(emp.getEmpid()+" "+ emp.getFname()+"  "+ emp.getLname()+ " "+emp.getGender()+ " "+emp.getMobileno()+
					" "+emp.getMail()+ " "+emp.getDesignation()+ " "+emp.getSalary()+ " "+emp.getJoiningdate()+ " "+emp.getDeptid() );
			/*logger.info(emp.getEmpid()+" "+ emp.getFname()+"  "+ emp.getLname()+ " "+emp.getGender()+ " "+emp.getMobileno()+
			" "+emp.getMail()+ " "+emp.getDesignation()+ " "+emp.getSalary()+ " "+emp.getJoiningdate()+ " "+emp.getDeptid() );*/
		     }
		}
		else
			System.out.println("No employee records available");
	} catch (EmployeeException e) {
		System.out.println(e.getMessage());
		//logger.error(e.getMessage());
	}
	
	break;
	
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------	
	
	
	case 3:
		
		//display updated employee details on console.
		    System.out.println("Enter Salary ");
			double salary1= sc.nextDouble();
			System.out.println("enter Employee id ");
			int empid= sc.nextInt();
			employee.setEmpid(empid);
			employee.setSalary(salary1);
			
		try {
			int rev= service.updateEmployee(employee);
			if(rev==1){
				System.out.println("salary updated successfully ");
				//logger.info("salary updated successfully ");
			}
			else{
				System.out.println("Employee record not available");
				//logger.info("Employee record not available");
			}
		} catch (EmployeeException e) {
			System.out.println(e.getMessage());
			//logger.error(e.getMessage());
		}				
		break;
	
	
	//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
   //-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	case 4:
		//System.out.println("Process got terminated ");
		//logger.info("Process got terminated ");
		break;
		default :System.out.println("please enter correct option ");
		//logger.info("please enter correct option ");
		
	}// end of switch 
	}while(option!=4); // end of do while 
	}// end of main method

}// end of class
