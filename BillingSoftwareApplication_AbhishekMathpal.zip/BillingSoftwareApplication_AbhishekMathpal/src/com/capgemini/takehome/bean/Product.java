package com.capgemini.takehome.bean;

public class Product {
	//variable declaration starts
	String productName;
	String category;
	String productDescription;
	int productCode;
	float productPrice;
	//variable declaration ends
	//declaring constructor
	public Product(String productName, String category, String productDescription, int productCode,
			float productPrice) {
		super();
		this.productName = productName;
		this.category = category;
		this.productDescription = productDescription;
		this.productCode = productCode;
		this.productPrice = productPrice;
	}
	//getter setter starts
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getProductDescription() {
		return productDescription;
	}
	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}
	public int getProductCode() {
		return productCode;
	}
	public void setProductCode(int productCode) {
		this.productCode = productCode;
	}
	public float getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(float productPrice) {
		this.productPrice = productPrice;
	}
	 //getter setter ends
	
	//Overriden toString
	@Override
	public String toString() {
		return "Product [productName=" + productName + ", category=" + category + ", productDescription="
				+ productDescription + ", productCode=" + productCode + ", productPrice=" + productPrice + "]";
	}
	
	
}
