package com.capgemini.xyz.service;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.dao.LoanDao;
import com.capgemini.xyz.exception.CustomerException;

public class LoanService implements ILoanService{

	LoanDao dao;
	public LoanService(){
		dao=new LoanDao();
	}
	@Override
	public long applyLoan(Loan loan) throws CustomerException {
		long id=dao.applyLoan(loan);
		return id;
	}

	@Override
	public Customer validateCustomer(Customer customer) throws CustomerException {
		
		return dao.validateCustomer(customer);
	}

	@Override
	public long insertCust(Customer cust)  throws CustomerException{
		long id=dao.insertCust(cust);
		return id;
	}

	@Override
	public double calculateEMI(double amount, int duration) throws CustomerException {
		
		return dao.calculateEMI(amount, duration);
	}

	

}
