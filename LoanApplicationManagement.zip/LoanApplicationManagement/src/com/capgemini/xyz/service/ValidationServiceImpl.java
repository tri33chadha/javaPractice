package com.capgemini.xyz.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationServiceImpl implements ValidationService{

	@Override
	public boolean validateCustomerName(String name) {
	
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(name);
		return matcher.matches();
	}

	@Override
	public boolean validateAddress(String address) {
		Pattern pattern= Pattern.compile("[A-Z][a-z]{2,19}");
		Matcher matcher= pattern.matcher(address);
		return matcher.matches();
	}
	
	
	@Override
	public boolean validateEmail(String email) {
		Pattern pattern= Pattern.compile("[A-Za-z0-9]*@capgemini.com");
		Matcher matcher= pattern.matcher(email);
		return matcher.matches();
	}

	@Override
	public boolean validateMobileNo(String mobno) {
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(mobno);
		return matcher.matches();
	}

}
