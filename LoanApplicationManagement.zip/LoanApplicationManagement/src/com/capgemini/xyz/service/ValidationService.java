package com.capgemini.xyz.service;

public interface ValidationService {

	public boolean validateCustomerName(String name);
	public boolean validateAddress(String address);
	public boolean validateEmail(String email);
	public boolean validateMobileNo(String mobno);
}
