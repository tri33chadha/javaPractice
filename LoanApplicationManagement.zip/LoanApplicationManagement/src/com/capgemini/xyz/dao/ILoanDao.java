package com.capgemini.xyz.dao;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.CustomerException;

public interface ILoanDao {

	public long applyLoan(Loan loan) throws CustomerException;
	public long insertCust(Customer cust) throws CustomerException;
	public double calculateEMI(double amount,int duration) throws CustomerException;
	public Customer validateCustomer(Customer customer) throws CustomerException;
	
}
