package com.capgemini.xyz.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.CustomerException;
import com.capgemini.xyz.util.DatabaseConnection;



public class LoanDao implements ILoanDao {


	Connection connection;
	public LoanDao() {
		connection= DatabaseConnection.getConnection();
	}
	protected void finalize(){
		try {
			connection.close();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
	}
	
	
	@Override
	public long applyLoan(Loan loan) throws CustomerException {
		String insQry="Insert into Loan values(Loan_seq.nextval,? ,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(insQry);
			Customer cust=new Customer();
			ps.setDouble(1, loan.getLoanAmount());
			ps.setLong(2, cust.getCustId());
			ps.setInt(3, loan.getDuration());
			
			int r= ps.executeUpdate();
			long custId=0;
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select Loan_seq.currval from dual");
					if(rs.next())
						custId=rs.getLong(1);
			}
		return custId;
		} catch (SQLException e) {
			throw new CustomerException(e.getMessage());
		}		
	}
	

	@Override
	public long insertCust(Customer cust) throws CustomerException {
		
		String insQry="Insert into Customer_Details values(Cust_seq.nextval,?,?,?,?)";
		try {
			PreparedStatement ps = connection.prepareStatement(insQry);
			
			ps.setString(1, cust.getCustName());
			ps.setString(2, cust.getAddress());
			ps.setString(3, cust.getEmail());
			ps.setString(4,cust.getMobile());
			
			int r= ps.executeUpdate();
			long custId=0;
			if(r==1){
					Statement st= connection.createStatement();
					ResultSet rs= st.executeQuery("select Cust_seq.currval from dual");
					if(rs.next())
						custId=rs.getLong(1);
			}
		return custId;
		} catch (SQLException e) {
			throw new CustomerException(e.getMessage());
		}		
	}
	@Override
	public double calculateEMI(double amount, int duration) throws CustomerException {
		double emi;
		double r= 9.5;
		double P= amount;
		int n=duration;
		emi=P*r*(1+r)*n/((1+r)*n-1);
		
		return emi;
	}
	
	
	@Override
	public Customer validateCustomer(Customer customer)
			throws CustomerException {
		// TODO Auto-generated method stub
		return null;
	}
}
