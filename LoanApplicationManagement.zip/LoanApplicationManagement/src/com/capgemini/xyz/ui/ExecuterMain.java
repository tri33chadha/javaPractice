package com.capgemini.xyz.ui;

import java.util.Scanner;

import com.capgemini.xyz.bean.Customer;
import com.capgemini.xyz.bean.Loan;
import com.capgemini.xyz.exception.CustomerException;
import com.capgemini.xyz.service.ILoanService;
import com.capgemini.xyz.service.LoanService;
import com.capgemini.xyz.service.ValidationService;
import com.capgemini.xyz.service.ValidationServiceImpl;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;



public class ExecuterMain {

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources/log4j.properties");
		Customer customer= new Customer();
		Loan loan= new Loan();
		ILoanService service= new LoanService();
		Logger logger=Logger.getLogger(ExecuterMain.class);
		ValidationService validation=new ValidationServiceImpl();
		Scanner sc= new Scanner(System.in);
		int option=0;
		do{
			 System.out.println("\n\n XYZ Finance Company welcomes you");
		     System.out.println("1. Register Customer");
	         System.out.println("2. Exit");
		     System.out.println("Enter Choice .");
		     option= sc.nextInt();
		     
		     switch(option){
		     
		     
		case 1:
			//Cust Name
			do{
			System.out.println("Enter Customer Name : ");
			logger.info("Enter Customer Name : ");
			String name=sc.next();
			boolean res=validation.validateCustomerName(name);
			if(res==true)
			{
				customer.setCustName(name);
				break;
			}
			else{
				System.out.println("Name should contain only alphabets...First Letter Capital");
			logger.info("Name should contain only alphabets...First Letter Capital");
			}
			}while(true);
			
			//Address
			do{
			System.out.println("Enter Address : ");
			logger.info("Enter Address : ");
			String name=sc.next();
			boolean res=validation.validateAddress(name);
			if(res==true)
			{
				customer.setAddress(name);
				break;
			}
			else{
				System.out.println("Place Name should contain only alphabets...First Letter Capital");
			logger.info("Name should contain only alphabets...First Letter Capital");
			}
			}while(true);
			
			//Email
			do{
				System.out.println("Enter Email : ");
				String email= sc.next();
				boolean res= validation.validateEmail(email);
				if(res==true)
					{
						customer.setEmail(email);
						break;
					}
					else{
						System.out.println("Mail id as: abcd@capgemini.com ");
				logger.info("Mail id as: abcd@capgemini.com ");
					}
				}while(true);
			
			do{
				System.out.println("Enter mobile No :");
				logger.info("Enter mobile No :");
				String mobno= sc.next();
				boolean res=validation.validateMobileNo(mobno);
				if(res)
				{
					customer.setMobile(mobno);
					break;
				}
				else{
					System.out.println("Mobile no shoule be 10 digit.");
				logger.info("Mobile no shoule be 10 digit.");
				}
			}while(true);
			
			try {
				long custId= service.insertCust(customer);
				System.out.println("Customer information saved successfully.");
				logger.info("Customer information saved successfully.");
				System.out.println("Your Customer Id is "+ custId );
				logger.info("Your Customer Id is "+ custId);
			} catch (CustomerException e) {
				System.out.println(e.getMessage());
				logger.error(e.getMessage());
			}	
			
			System.out.println("Do you wish to apply for Loan? (Yes/No)");
			String result=sc.next();
			if (result!= "No"){
				try {
				//loan amount
				System.out.println("Enter the loan amount");
				double loanAmount=sc.nextDouble();
				System.out.println("Enter the loan duration");
				int duration=sc.nextInt();
				System.out.println("Enter Customer ID");
				long custID=sc.nextInt();	
					System.out.println("For loan amount " +loanAmount+" and "+duration+" Years durations. ");
					logger.info("For loan amount " +loanAmount+" and "+duration+" Years durations. ");
					System.out.println("Your EMI per month will be "+service.calculateEMI(loanAmount, duration)/30);
					logger.info("Your EMI per month will be "+service.calculateEMI(loanAmount, duration)/30);
				} catch (CustomerException e) {
					System.out.println(e.getMessage());
					logger.error(e.getMessage());
				}
				
				System.out.println("Do you wish to apply for loan now? (Yes/No)");
				String result1=sc.next();
				if (result1!= "No"){
				try {
					long loanID= service.applyLoan(loan);
					System.out.println("Your Loan request is generated.");
					logger.info("Your Loan request is generated.");
					System.out.println("Your Loan ID is "+ loanID );
					logger.info("Your Loan ID is "+ loanID );
				} catch (CustomerException e) {
					System.out.println(e.getMessage());
					logger.error(e.getMessage());
				}
			}
				else {
					System.out.println("Process got terminated ");
					logger.info("Process got terminated ");
					break;
				}
			}
			else {
				System.out.println("Process got terminated ");
				logger.info("Process got terminated ");
				break;
			}
				
			
		case 2:
			System.out.println("Process got terminated ");
			logger.info("Process got terminated ");
			break;
			default :System.out.println("please enter correct option ");
			logger.info("please enter correct option ");
			
		}// end of switch 
		}while(option!=2); // end of do while 
		}// end of main method
	
}// end of class
