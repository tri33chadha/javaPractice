package com.cg.payroll.util;

import java.io.File;
import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.HashMap;
import java.util.Properties;

import com.cg.payroll.beans.Associate;

public class PayrollDBUtil {
	private static Connection con=null;
	public static Connection getDBConnection() {
		if(con==null) {
		Properties payrollProperties=new Properties();
		try {
				payrollProperties.load(new FileInputStream(new File(".//resources//payroll.properties")));
				String driver=payrollProperties.getProperty("driver");
				String url=payrollProperties.getProperty("url");
				String user=payrollProperties.getProperty("user");
				String password=payrollProperties.getProperty("password");
				//load driver
				Class.forName(driver);
				//open connection
				con=DriverManager.getConnection(url,user,password);
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		}
		return con;

}
}
