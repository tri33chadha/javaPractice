 package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;

public class PayrollServicesImpl implements PayrollServices{

	private AssociateDAO associateDao;
	
	 public PayrollServicesImpl() {
		associateDao=new AssociateDAOImpl();
	}
	public PayrollServicesImpl(AssociateDAO associateDao)
	{
		super();
		this.associateDao=associateDao;
	}
	
	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearIyinvestmentUnder8oC, int basicSalary, int epf, int companyPf,
			int accountNumber, String bankName, String ifscCode) {
		BankDetails bankDetails=new BankDetails(accountNumber, bankName, ifscCode);
		Salary sal=new Salary(basicSalary, epf, companyPf);
		Associate associate=new Associate(yearIyinvestmentUnder8oC, accountNumber, firstName, lastName, department, designation, pancard, emailId,sal,bankDetails);
		
		associate=associateDao.save(associate);
		return associate.getAssociateId();
	}

	@Override
	public int calculateNetSalary(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=associateDao.findOne(associateId);
		int netSalary=0;
		if(associate==null)
		{
			throw new AssociateDetailNotfoundException("Not found"+associateId);
		}
		else
		{
			associate.getSal().setHra((int)(associate.getSal().getBasicSalary()*0.3));
			associate.getSal().setConveyenceAllowance((int)(associate.getSal().getBasicSalary()*0.3));
			associate.getSal().setPersonalAllowance((int)(associate.getSal().getBasicSalary()*0.2));
			associate.getSal().setOtherAllowance((int)(associate.getSal().getBasicSalary()*0.25));

			int monthlyGrossSalary= associate.getSal().getBasicSalary()+associate.getSal().getCompanyPf()+associate.getSal().getHra()+
					associate.getSal().otherAllowance+associate.getSal().personalAllowance+
					associate.getSal().getConveyenceAllowance()+associate.getSal().getEpf();
			associate.getSal().setGrossSalary(monthlyGrossSalary);
			int annualGrossSalary=12* monthlyGrossSalary;

			int investment=associate.getYearlyInvestmentUnder80C()+associate.getSal().getEpf()+associate.getSal().getCompanyPf();
			if(investment>=150000)
				investment=150000;

			if(annualGrossSalary<=250000)
			{
				netSalary=(int)(annualGrossSalary-associate.getSal().getEpf()-associate.getSal().getCompanyPf());
			}
			else if(monthlyGrossSalary>250000 && annualGrossSalary<=500000)
			{
				netSalary=(int)(annualGrossSalary-((annualGrossSalary-investment)*0.1)-associate.getSal().getEpf()-associate.getSal().getCompanyPf());
				associate.getSal().setMonthlyTax((int) ((annualGrossSalary-investment)*0.1)/12);
			}
			else if(annualGrossSalary>500000 && annualGrossSalary<=1000000)
			{
				int tax2 = (int)((annualGrossSalary-500000*0.2));
				int tax1=(int)((25000-investment)*0.1);
				associate.getSal().setMonthlyTax((tax1+tax2)/12);
				netSalary=annualGrossSalary-tax1-tax2-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
			}
			else if(annualGrossSalary>1000000)
			{
				int tax3=(int)((annualGrossSalary-1000000)*0.3);
				int tax2=10000;
				int tax1=(int)((25000-investment)*0.1);
				associate.getSal().setMonthlyTax((tax1+tax2+tax3)/12);
				netSalary=annualGrossSalary-tax1-tax2-tax3-associate.getSal().getEpf()-associate.getSal().getCompanyPf();
				associate.getSal().setNetSalary(netSalary);
				associateDao.update(associate);
			}
		}
			return netSalary;
	}

	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailNotfoundException {
		Associate associate=associateDao.findOne(associateId);
		if(associate==null)
			throw new AssociateDetailNotfoundException("Associate detail not found for id"+associateId);
		return associate;
	}

	@Override
	public List<Associate> getallAssociateDetails() {
		return associateDao.findAll();
	}
	//private AssociateDAO associateDao=new Associate();
	
}
