package com.cg.gymsystem.beans;

public class Member {
	int memberId;
	Date joinDate;
	Trainer trainer;
	Trainee trainee;
	public Member( Date joinDate, Trainer trainer, Trainee trainee,int memberId) {
		super();
		this.memberId = memberId;
		this.joinDate = joinDate;
		this.trainer = trainer;
		this.trainee = trainee;
	}
	public Member( Date joinDate, Trainer trainer, Trainee trainee) {
		super();
		this.joinDate = joinDate;
		this.trainer = trainer;
		this.trainee = trainee;
	}
	public int getMemberId() {
		return memberId;
	}
	public void setMemberId(int memberId) {
		this.memberId = memberId;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public Trainer getTrainer() {
		return trainer;
	}
	public void setTrainer(Trainer trainer) {
		this.trainer = trainer;
	}
	public Trainee getTrainee() {
		return trainee;
	}
	public void setTrainee(Trainee trainee) {
		this.trainee = trainee;
	}
	@Override
	public String toString() {
		return "Member [memberId=" + memberId + ", joinDate=" + joinDate + ", trainer=" + trainer + ", trainee="
				+ trainee + "]";
	}


	
}
