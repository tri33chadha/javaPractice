package com.cg.gymsystem.beans;

public class Trainee {
	String name;
	int traineeID;
	int age;
	float weight;
	float height;
	public Trainee(String name, int age, float weight, float height) {
		super();
		this.name = name;
		this.age = age;
		this.weight = weight;
		this.height = height;
	}
	
	public Trainee(String name, int traineeID, int age, float weight, float height) {
		super();
		this.name = name;
		this.traineeID = traineeID;
		this.age = age;
		this.weight = weight;
		this.height = height;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}
	public float getHeight() {
		return height;
	}
	public void setHeight(float height) {
		this.height = height;
	}
	
	
	public int getTraineeID() {
		return traineeID;
	}

	public void setTraineeID(int traineeID) {
		this.traineeID = traineeID;
	}

	@Override
	public String toString() {
		return "Trainee [name=" + name + ", traineeID=" + traineeID + ", age=" + age + ", weight=" + weight
				+ ", height=" + height + "]";
	}

	
	
}
