package com.cg.gymsystem.util;
import com.cg.gymsystem.beans.*;
import java.util.HashMap;

public class GymSysDBUtil {
	public static HashMap<Integer,Member> members=new HashMap<>();
	public static int Mem_ID=1000;
	public static int getMemId()
	{
		return Mem_ID++;
	}
}
