package com.cg.gymsystem.services;

import java.util.List;

import com.cg.gymsystem.beans.Member;
import com.cg.gymsystem.exception.MemberNotFoundException;
import com.cg.gymsystem.exception.WrongDateFormatException;

public interface GymSystemServices {
	
	public Member saveDetails(String name,int age,float weight,float height,int day,int month,int year,String pan,String adhaar,float salary)throws MemberNotFoundException,WrongDateFormatException;
	public Member getDetails(int memId)throws MemberNotFoundException,WrongDateFormatException;
	public List<Member> getAllMember()throws MemberNotFoundException,WrongDateFormatException;
}
