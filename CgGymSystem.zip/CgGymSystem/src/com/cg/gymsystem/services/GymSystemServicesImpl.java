package com.cg.gymsystem.services;

import java.util.ArrayList;
import java.util.List;

import com.cg.gymsystem.beans.*;
import com.cg.gymsystem.exception.MemberNotFoundException;
import com.cg.gymsystem.exception.WrongDateFormatException;
import com.cg.gymsystem.servicesDao.GymSystemServicesDao;
import com.cg.gymsystem.servicesDao.GymSystemServicesDaoImpl;
import com.cg.gymsystem.util.GymSysDBUtil;

public class GymSystemServicesImpl implements GymSystemServices{
	
	private GymSystemServicesDaoImpl objectDao=new GymSystemServicesDaoImpl();
	 @Override
	public Member saveDetails(String name, int age, float weight, float height, int day, int month, int year,String pan,
		String adhaar, float salary) throws MemberNotFoundException, WrongDateFormatException {
		 if(day<1||day>31||month>12||month<1||year>2019||year<1950)
		throw new WrongDateFormatException("Wrong Date");
		Date joinDate=new Date(day,month,year);
		Trainee trainee=new Trainee(name, age, weight, height);
		Trainer trainer=new Trainer(name, age, pan, salary);
		Member mem=new Member(joinDate, trainer, trainee);
		mem=objectDao.save(mem);
		return mem;
	}

	@Override
	public Member getDetails(int memId) throws MemberNotFoundException, WrongDateFormatException {
		Member mem =objectDao.findOne(memId);
		if(mem==null)
			throw new MemberNotFoundException("Member not found");
		return mem;
	}

	@Override
	public List<Member> getAllMember() throws MemberNotFoundException, WrongDateFormatException {
		return objectDao.findAll();
	}

}
