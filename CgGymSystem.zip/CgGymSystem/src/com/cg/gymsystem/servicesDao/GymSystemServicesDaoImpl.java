package com.cg.gymsystem.servicesDao;

import java.util.ArrayList;
import java.util.List;

import com.cg.gymsystem.beans.Member;
import com.cg.gymsystem.exception.MemberNotFoundException;
import com.cg.gymsystem.exception.WrongDateFormatException;
import com.cg.gymsystem.util.GymSysDBUtil;

public class GymSystemServicesDaoImpl implements GymSystemServicesDao {

	@Override
	public Member save(Member mem) throws MemberNotFoundException, WrongDateFormatException {
		int a=GymSysDBUtil.getMemId();
		mem.setMemberId(a);
		mem.getTrainee().setTraineeID(GymSysDBUtil.getMemId());
		mem.getTrainer().setTrainerId(GymSysDBUtil.getMemId());
		GymSysDBUtil.members.put(a, mem);
		return mem;
	}

	@Override
	public Member findOne(int memId) throws MemberNotFoundException, WrongDateFormatException {
		return GymSysDBUtil.members.get(memId);
	}

	@Override
	public List<Member> findAll() throws MemberNotFoundException, WrongDateFormatException {
		ArrayList <Member> al=new ArrayList(GymSysDBUtil.members.values());
		return al;
	}

}
