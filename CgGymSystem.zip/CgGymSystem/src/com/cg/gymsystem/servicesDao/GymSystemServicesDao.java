package com.cg.gymsystem.servicesDao;

import java.util.List;

import com.cg.gymsystem.beans.Member;
import com.cg.gymsystem.exception.MemberNotFoundException;
import com.cg.gymsystem.exception.WrongDateFormatException;

public interface GymSystemServicesDao {
	public Member save(Member mem)throws MemberNotFoundException,WrongDateFormatException;
	
	public Member findOne(int memId)throws MemberNotFoundException,WrongDateFormatException;
	
	public List<Member> findAll()throws MemberNotFoundException,WrongDateFormatException;
}
