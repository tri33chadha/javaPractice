package com.cg.mobapp.service;

import java.util.List;

import com.cg.mobapp.dao.MobileDao;
import com.cg.mobapp.dao.MobileDaoImp1;
import com.cg.mobapp.dto.Mobile;
import com.cg.mobapp.exception.MobileException;

public class MobileServiceImp1 implements MobileService {

	MobileDao dao;
	public MobileServiceImp1(){
		dao=new MobileDaoImp1();
	}
	@Override
	public int addMobile(Mobile mobile) throws MobileException {
		// TODO Auto-generated method stub
		int id=dao.addMobile(mobile);
		return id;
	}

	@Override
	public Mobile getMobileDetails(int id) throws MobileException {
		// TODO Auto-generated method stub
		return dao.getMobileDetails(id);
	}

	@Override
	public int updateMobileDetails(Mobile mob) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteMobile(int id) throws MobileException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Mobile> getMobileList() throws MobileException {
		// TODO Auto-generated method stub
		return dao.getMobileList();
	}

}
