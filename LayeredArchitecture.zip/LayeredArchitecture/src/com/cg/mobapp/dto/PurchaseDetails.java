package com.cg.mobapp.dto;

public class PurchaseDetails {

}
