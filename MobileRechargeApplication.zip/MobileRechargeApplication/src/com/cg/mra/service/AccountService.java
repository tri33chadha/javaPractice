package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.excpetions.AccountNotFoundException;
import com.cg.mra.excpetions.InvalidMobileNumberException;

public interface AccountService {
int rechargeAccount(String mobileno, int rechargeAmount) throws AccountNotFoundException, InvalidMobileNumberException;
public Account getAccountDetails(String mobileNo) throws AccountNotFoundException;
}
