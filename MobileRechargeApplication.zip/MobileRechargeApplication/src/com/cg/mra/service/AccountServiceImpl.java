package com.cg.mra.service;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.excpetions.AccountNotFoundException;
import com.cg.mra.excpetions.InvalidMobileNumberException;
public class AccountServiceImpl implements AccountService {
	AccountDao accountDao=new AccountDaoImpl();
	@Override
	public int rechargeAccount(String mobileno, int rechargeAmount) throws AccountNotFoundException, InvalidMobileNumberException{
		Account account=accountDao.getAccountDetails(mobileno);
		if(account==null)
			throw new AccountNotFoundException();
		if(!(mobileno.length()==10))
			throw new InvalidMobileNumberException();
		int totalBalance=account.getAccountBalance()+rechargeAmount;
		account.setAccountBalance(totalBalance);
	    AccountDaoImpl.accountEntry.put(mobileno, account);
		return totalBalance;
	}
	public Account getAccountDetails(String mobileNo) throws AccountNotFoundException{
		Account account=accountDao.getAccountDetails(mobileNo);
		if(account==null)
			throw new AccountNotFoundException();
		return account;
	}

}
