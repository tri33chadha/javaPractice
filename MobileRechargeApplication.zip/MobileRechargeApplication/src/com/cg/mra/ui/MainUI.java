package com.cg.mra.ui;
import java.util.Scanner;

import com.cg.mra.excpetions.AccountNotFoundException;
import com.cg.mra.excpetions.InvalidMobileNumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
public class MainUI {
	public static void main(String args[]) {
		Scanner scan=new Scanner(System.in);
		AccountService services=new AccountServiceImpl();
		System.out.println("Choose any one option\n "
				+ "1) Account Balance Enquriy\n"
				+ "2) Recharge Account\n"
				+ "3) Exit ");
		int choice=scan.nextInt();
		switch(choice) {
		case 1:
			System.out.println("Enter Mobile No:");
			String mobileNo=scan.next();
			try {
			System.out.println("Your current balance is :"+services.getAccountDetails(mobileNo).getAccountBalance());
			}
			catch(AccountNotFoundException e) {
				System.out.println("ERROR: Given account Id Does Not Exists");
			}
			break;
		case 2:
			System.out.println("Enter mobileNo:");
			String mobileno=scan.next();
			System.out.println("Enter Recharge Amount:");
			int amount=scan.nextInt();
			System.out.println("Your account recharged successfully");
			services.rechargeAccount(mobileno, amount);
			try {
			System.out.println("Hello "
			+services.getAccountDetails(mobileno).getCustomerName()+",Availabe Balance is"+services.getAccountDetails(mobileno).getAccountBalance());
			}
			catch(AccountNotFoundException  | InvalidMobileNumberException e) {
				System.out.println("ERROR: Cannot Recharge Account as Given Mobile No Does Not Exists");
			}
			break;
		case 3:
			System.exit(0);
			break;
		default:
			System.out.println("Wrong choice");
		}
	}
}