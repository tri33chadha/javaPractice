package com.cg.mra.testservices;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.excpetions.AccountNotFoundException;
import com.cg.mra.excpetions.InvalidMobileNumberException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
public class TestServices {
	private static AccountService services;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new AccountServiceImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1=new Account("prepaid", "shreyansh", 200);
		Account account2=new Account("prepaid", "Ishita",100);
		AccountDaoImpl.accountEntry.put("9876549876", account1);
		AccountDaoImpl.accountEntry.put("9870010016", account2);
	}
	@Test
	public void testRechargeAccountForValidData() {
		int expected=services.rechargeAccount("9876549876", 100);
		int actual=300;
		Assert.assertEquals(expected, actual);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testRechargeAccountForInvalidData() {
		services.rechargeAccount("9456586780", 100);
	}

	/*
	 * @Test(expected=InvalidMobileNumberException.class) public void
	 * testRechargeAccountForInvalidMobileNumber() {
	 * services.rechargeAccount("94508678", 100); }
	 */
	@Test
	public void testgetAccountDetailsForValidData() {
		int expected=services.getAccountDetails("9870010016").getAccountBalance();
		int actual=100;
		Assert.assertEquals(expected, actual);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testgetAccountDetailsForInvalidData() {
		services.getAccountDetails("9879010016").getAccountBalance();
	}
	@AfterClass
	public static void tearDownTestData() {
		services=null;
	}

}
