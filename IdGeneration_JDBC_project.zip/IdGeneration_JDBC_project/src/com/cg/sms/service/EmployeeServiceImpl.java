package com.cg.sms.service;

import com.cg.sms.dao.EmployeeDAO;
import com.cg.sms.dao.EmployeeDAOImpl;
import com.cg.sms.exceptions.EMSException;
import com.cg.sms.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDAO employeeDao = new EmployeeDAOImpl();

	@Override
	public int insertEmployee(Employee employee) throws EMSException {
		return employeeDao.insertEmployee(employee);
	}

}
