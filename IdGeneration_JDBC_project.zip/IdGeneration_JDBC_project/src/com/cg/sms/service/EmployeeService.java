package com.cg.sms.service;

import com.cg.sms.exceptions.EMSException;
import com.cg.sms.model.Employee;

public interface EmployeeService {

	int insertEmployee(Employee employee) throws EMSException;

	
}
