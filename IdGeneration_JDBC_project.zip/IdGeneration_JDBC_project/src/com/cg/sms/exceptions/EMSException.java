package com.cg.sms.exceptions;

public class EMSException extends Exception {

	public EMSException(String message) {
		super(message);
	}
}
