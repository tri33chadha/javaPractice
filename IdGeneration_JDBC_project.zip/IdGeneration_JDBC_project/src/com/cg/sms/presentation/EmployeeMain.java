package com.cg.sms.presentation;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.cg.sms.exceptions.EMSException;
import com.cg.sms.model.Employee;
import com.cg.sms.service.EmployeeService;
import com.cg.sms.service.EmployeeServiceImpl;

public class EmployeeMain {

	public static void main(String[] args) {

		Scanner scanner = new Scanner(System.in);

		EmployeeService service = new EmployeeServiceImpl();

		System.out.println("Enter Name:");
		String name = scanner.nextLine();
		System.out.println("Enter Desig:");
		String desig = scanner.nextLine();
		System.out.println("Enter salary:");
		double salary = scanner.nextDouble();
		scanner.nextLine();
		LocalDate dob = null;
		DateTimeFormatter formatter = null;
		boolean dateFlag = false;

		do {
			scanner = new Scanner(System.in);
			System.out.println("Enter  DOB: (dd-MM-yyyy)");
			String dateOfBirth = scanner.nextLine();
			formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
			try {
				dob = LocalDate.parse(dateOfBirth, formatter);
				dateFlag = true;
			} catch (DateTimeException e) {
				dateFlag = false;
				System.err.println("Enter date in the valid format (dd-MM-yyyy)");
			}
		} while (!dateFlag);

		Employee employee = new Employee(name, desig, dob, salary);

		try {
			int genId = service.insertEmployee(employee);
			System.out.println(" ur record inserted with the given id: " + genId);
		} catch (EMSException e) {
			System.err.println(e.getMessage());
		}

	}
}
