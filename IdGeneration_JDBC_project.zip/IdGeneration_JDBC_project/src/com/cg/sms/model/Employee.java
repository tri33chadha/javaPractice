package com.cg.sms.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Employee implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6296278598140695235L;

	private Integer id;
	private String name;
	private String desig;
	private LocalDate dob;
	private Double salary;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(Integer id, String name, String desig, LocalDate dob, Double salary) {
		super();
		this.id = id;
		this.name = name;
		this.desig = desig;
		this.dob = dob;
		this.salary = salary;
	}

	public Employee(String name, String desig, LocalDate dob, Double salary) {
		super();
		this.name = name;
		this.desig = desig;
		this.dob = dob;
		this.salary = salary;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDesig() {
		return desig;
	}

	public void setDesig(String desig) {
		this.desig = desig;
	}

	public LocalDate getDob() {
		return dob;
	}

	public void setDob(LocalDate dob) {
		this.dob = dob;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", desig=" + desig + ", dob=" + dob + ", salary=" + salary
				+ "]";
	}

}
