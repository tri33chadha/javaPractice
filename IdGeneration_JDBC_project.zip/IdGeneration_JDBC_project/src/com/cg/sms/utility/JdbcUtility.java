package com.cg.sms.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.sms.exceptions.EMSException;

public class JdbcUtility {

	private static Connection connection = null;

	public static Connection getConnection() throws EMSException {

		File file = new File("resources/jdbc.properties");
		FileInputStream inputStream = null;

		try {
			inputStream = new FileInputStream(file);

			Properties properties = new Properties();
			properties.load(inputStream);

			String driver = properties.getProperty("db.driver");
			String url = properties.getProperty("db.url");
			String username = properties.getProperty("db.username");
			String password = properties.getProperty("db.password");

			Class.forName(driver);
			connection = DriverManager.getConnection(url, username, password);

		} catch (FileNotFoundException e) {
			throw new EMSException("no file present with the given name");
		} catch (IOException e) {
			throw new EMSException("unable to read the data from File");
		} catch (ClassNotFoundException e) {
			throw new EMSException("unable to load driver");
		} catch (SQLException e) {
			throw new EMSException("connection issues");
		}

		return connection;
	}
}
