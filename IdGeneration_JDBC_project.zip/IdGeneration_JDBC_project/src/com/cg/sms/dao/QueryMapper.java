package com.cg.sms.dao;

public interface QueryMapper {

	String insertQuery = "insert into employee_info_table(id,name,desig,date_of_birth,salary) values(emp_info_seq.nextval,?,?,?,?)";

	String getGeneratedId = "select emp_info_seq.currval from dual";

}
