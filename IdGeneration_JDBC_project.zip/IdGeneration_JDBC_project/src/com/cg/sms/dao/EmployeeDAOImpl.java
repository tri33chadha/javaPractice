package com.cg.sms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.cg.sms.exceptions.EMSException;
import com.cg.sms.model.Employee;
import com.cg.sms.utility.JdbcUtility;

public class EmployeeDAOImpl implements EmployeeDAO {

	Connection connection = null;
	PreparedStatement statement = null;

	@Override
	public int insertEmployee(Employee employee) throws EMSException {

		connection = JdbcUtility.getConnection();
		int generatedId = 0;
		LocalDate localDate = employee.getDob();
		Date dob = Date.valueOf(localDate);
		
		try {
			statement = connection.prepareStatement(QueryMapper.insertQuery);
			statement.setString(1, employee.getName());
			statement.setString(2, employee.getDesig());
			statement.setDate(3, dob);
			statement.setDouble(4, employee.getSalary());
			statement.executeUpdate();
			connection.commit();
			statement = connection.prepareStatement(QueryMapper.getGeneratedId);
			ResultSet resultSet = statement.executeQuery();

			resultSet.next();
			generatedId = resultSet.getInt(1);
			
			/*Date date = resultSet.getDate(3);
			LocalDate localDate2 = date.toLocalDate();
			employee.setDob(localDate2);*/
			

		} catch (SQLException e) {
			throw new EMSException("problem");
		}
		return generatedId;
	}

}
