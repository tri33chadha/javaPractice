package com.cg.sms.dao;

import com.cg.sms.exceptions.EMSException;
import com.cg.sms.model.Employee;

public interface EmployeeDAO {

	int insertEmployee(Employee employee) throws EMSException;

	

}
